# Brick → Wall → PolyU Building

32 seconds, 1280 × 720, 30 fps. Cream background and brick-red line drawing. Only the first sentence appears; there is no final title card, B-roll or other text. No recorded narration supplied.

## Timeline

- 0–4s: one outline brick is drawn in place, with “What makes a structure last?” above it.
- 4–10.6s: 14 additional line bricks settle in to form a three-row wall.
- 10.6–13.5s: the view pulls away; brick vertices interpolate into the perspective plane of the reference photo's right-wing facade.
- 12–14.6s: a matched dissolve from the brick wall to the continuous architectural outline.
- 14.6–30s: preserve the previous version's architectural drawing, cylinder and wing proportions.
- 30–32s: hold on the completed line-art building, without text.

## Source

`src/brick-to-building/Opening.tsx` composes the two stages. `BrickWallIntro.tsx` handles brick outlines, timing and the perspective transition. `ContinuousLine.tsx` progressively reveals the unbroken building path. `PolyUBuilding.tsx` retains the photo-based trace. `config.ts` controls dimensions, color, line width, phase timings, wall rows/columns, reveal times and camera transition.

The brick stage uses one path per brick; the building stage retains one continuous path. A gentle cross dissolve bridges them, rather than claiming every brick outline is a single pen trajectory.

## Commands

```bash
cd /path/to/unzipped-project
npm ci
npm start -- --port=3100 --no-open
npm run typecheck
npm run render
```

Select composition `BrickToBuildingOpening`. Output: `out/brick-to-building-opening.mp4`. The original two versions remain available.

Remotion manages its browser automatically on Mac.
