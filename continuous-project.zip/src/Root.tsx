import React from 'react';
import {Composition} from 'remotion';
import {ContinuousOpening} from './continuous/Opening';
import {LINE_CONFIG as C} from './continuous/config';
export const Root:React.FC=()=> <Composition id="ContinuousOpening" component={ContinuousOpening} width={C.width} height={C.height} fps={C.fps} durationInFrames={C.duration*C.fps}/>;
