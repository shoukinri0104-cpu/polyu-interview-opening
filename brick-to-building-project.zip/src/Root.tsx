import React from 'react';
import {Composition} from 'remotion';
import {BrickToBuildingOpening} from './brick-to-building/Opening';
import {LINE_CONFIG as C} from './brick-to-building/config';
export const Root:React.FC=()=> <Composition id="BrickToBuildingOpening" component={BrickToBuildingOpening} width={C.width} height={C.height} fps={C.fps} durationInFrames={C.duration*C.fps}/>;
