// Manually traced from the supplied photo in its original 1400 × 650 proportions.
// Each step appends to ONE pen trajectory. There are no separate window paths.
// Retracing existing edges lets the pen reach another contour without lifting.
export type Point = readonly [number,number];
const points:Point[]=[];
const marks:number[]=[0];
const to=(x:number,y:number)=>points.push([x,y]);
const curve=(c1:Point,c2:Point,end:Point)=>{
 const start=points[points.length-1];
 for(let i=1;i<=24;i++){
  const t=i/24,u=1-t;
  to(u*u*u*start[0]+3*u*u*t*c1[0]+3*u*t*t*c2[0]+t*t*t*end[0],u*u*u*start[1]+3*u*u*t*c1[1]+3*u*t*t*c2[1]+t*t*t*end[1]);
 }
};
const length=()=>points.reduce((sum,p,i)=>i?sum+Math.hypot(p[0]-points[i-1][0],p[1]-points[i-1][1]):0,0);
const mark=()=>marks.push(length());
// 0–4: the beginning of a quiet, almost abstract ground line.
to(80,548);curve([125,548],[145,533],[190,533]);mark();
// 4–12: a continuous ground/plinth, with the photograph's stepped lower edge.
curve([245,529],[302,548],[269,562]);curve([204,583],[136,566],[184,553]);curve([205,547],[225,542],[247,533]);to(247,509);to(374,509);to(374,526);to(614,526);to(614,542);to(690,542);to(690,525);to(1098,525);mark();
// 12–22: right-wing perspective, tall cylinder, then the receding left wing.
to(1098,319);to(690,155);to(657,181);to(617,187);
to(617,91);curve([617,49],[555,17],[483,12]);curve([442,8],[404,31],[404,77]);
to(404,215);to(378,214);to(322,198);to(248,390);to(248,487);
to(225,487);to(225,455);to(190,459);to(190,438);curve([164,417],[117,416],[94,424]);
to(94,468);to(190,468);to(225,455);to(225,487);to(248,487);to(248,390);to(322,198);to(378,214);to(404,215);
// Complete the cylinder's lower sweep; preserve the dominant curved tower mass.
to(404,471);curve([404,501],[459,516],[520,515]);curve([563,515],[602,504],[617,487]);
to(617,187);to(657,181);to(657,483);to(690,505);to(1098,525);mark();
// 22–30: restrained facade rhythm and cylindrical contours.
// Right facade: bands descend toward the vanishing direction in the photograph.
to(1098,319);to(690,155);to(690,196);
for(const [a,b] of [[196,354],[253,399],[311,445],[371,490],[429,514]] as Point[]){
 to(690,a);to(1098,b);to(1098,b+9);to(690,a+13);to(690,a);
 // Return along the same band and left edge, without extra diagonals.
}
to(690,505);to(657,483);to(657,181);to(617,187);to(617,487);
// Curved rim at the tower's roof, and its gently curved vertical seam.
to(617,91);curve([617,49],[555,17],[483,12]);curve([442,8],[404,31],[404,77]);
curve([414,25],[449,17],[488,21]);curve([550,27],[602,52],[617,91]);
curve([602,52],[550,27],[488,21]);to(530,30);curve([531,173],[532,362],[532,513]);
curve([532,362],[531,173],[530,30]);to(488,21);curve([449,17],[414,25],[404,77]);
to(404,215);to(378,214);to(322,198);
// Left wing: oblique window strips and stepped receding edge.
for(const [y,far] of [[236,403],[289,433],[344,464],[398,495],[454,509]] as Point[]){
 to(322,y);to(378,y+13);to(378,y+29);to(322,y+16);
 to(248,far+12);to(248,far);to(322,y);
}
to(322,470);to(378,485);to(404,471);mark();
export const BUILDING = {
 points,
 path:'M '+points.map(([x,y])=>[x+.55*Math.sin(y*.071+x*.019),y+.5*Math.sin(x*.043-y*.017)].map(n=>n.toFixed(2)).join(' ')).join(' L '),
 length:length(), milestones:marks,
};
