import React from 'react';
import {Easing,interpolate,spring,useCurrentFrame,useVideoConfig} from 'remotion';
import {LINE_CONFIG as C} from './config';
const clamp={extrapolateLeft:'clamp',extrapolateRight:'clamp'} as const;
type P=readonly [number,number];
// Draw the front, upper face and side without lifting the pen.
const corners:P[]=[[0,0],[1,0],[1,1],[0,1],[0,0],[.055,-.12],[1.055,-.12],[1,0],[1,1],[1.055,.88],[1.055,-.12]];
const lengths=corners.map((p,i)=>i?Math.hypot(p[0]-corners[i-1][0],p[1]-corners[i-1][1]):0);
const total=lengths.reduce((a,b)=>a+b,0);
const order=[{col:2,row:0},...Array.from({length:C.wall.rows},(_,row)=>Array.from({length:C.wall.columns},(_,col)=>({col,row}))).flat().filter(p=>p.col!==2||p.row!==0)];
export const BrickWallIntro:React.FC=()=>{
 const frame=useCurrentFrame();const {fps}=useVideoConfig();const t=frame/fps;
 if(t>=C.wall.fadeEnd)return null;
 const pull=interpolate(t,[C.wall.pullStart,C.wall.pullEnd],[0,1],{...clamp,easing:Easing.inOut(Easing.cubic)});
 const opacity=interpolate(t,[C.wall.pullEnd,C.wall.fadeEnd],[1,0],clamp);
 const map=(col:number,row:number,p:P):P=>{
  const gap=.035;
  const u=(col+p[0]*(1-gap)+(row%2)*.18)/C.wall.columns;
  const v=(C.wall.rows-1-row+p[1]*(1-gap))/C.wall.rows;
  // Close-up wall, then a perspective match to the PHOTO's right-hand facade.
  const close:P=[640+(u-.5)*650,465+(v-1)*195];
  const x=690+408*u;
  const y=155+164*u+(350-144*u)*(.3+.58*v);
  const far:P=[C.drawing.left+x*C.drawing.width/1400,C.drawing.top+y*C.drawing.height/650];
  return [close[0]+(far[0]-close[0])*pull,close[1]+(far[1]-close[1])*pull];
 };
 return <svg width={1280} height={720} viewBox="0 0 1280 720" style={{position:'absolute',inset:0,opacity}}>
  {order.map(({col,row},i)=>{
   const at=i===0?C.wall.firstBrick:C.wall.stackStart+(i-1)*C.wall.interval;
   const local=frame-at*fps;
   if(local<0)return null;
   const progress=interpolate(local,[0,(i===0?1.55:.62)*fps],[0,1],clamp);
   const settle=spring({frame:local,fps,durationInFrames:Math.round(.85*fps),config:{damping:28,stiffness:70,mass:1.6,overshootClamping:true}});
   let budget=total*progress;const visible:P[]=[corners[0]];
   for(let j=1;j<corners.length;j++){
    if(budget>=lengths[j]){visible.push(corners[j]);budget-=lengths[j];}
    else{const a=corners[j-1],b=corners[j];visible.push([a[0]+(b[0]-a[0])*budget/lengths[j],a[1]+(b[1]-a[1])*budget/lengths[j]]);break;}
   }
   const path='M '+visible.map(p=>{const [x,y]=map(col,row,p);return `${x.toFixed(2)} ${(y-(i===0?0:22*(1-settle)*(1-pull))).toFixed(2)}`;}).join(' L ');
   return <path key={i} d={path} fill="none" stroke={C.brickRed} strokeWidth={2.2-pull*.4} strokeLinecap="round" strokeLinejoin="round"/>;
  })}
 </svg>;
};
