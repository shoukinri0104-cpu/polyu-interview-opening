# Continuous PolyU Opening

This version traces the supplied photograph's actual massing: the tall, curved cylinder at left-of-centre, the receding left wing, and the long right facade with descending window bands. It uses ONE SVG path, one initial M command, no disconnected subpaths, no block animation, no labels and no end title. Building signage and vegetation are omitted to keep the architecture readable. A small ground-level loop gives the uninterrupted line a flowing sketch character.

The brick-red tone is a visual approximation from the facade, not an exact pixel sample. The final 2 seconds hold the completed path, on a cream background.

## Files

```
src/continuous/
  Opening.tsx           # composition, opening sentence, cream background
  ContinuousLine.tsx    # single-path reveal using interpolate and measured length
  PolyUBuilding.tsx     # editable photo-based points, curves and phase milestones
  config.ts            # timing, color, dimensions and line thickness
src/Root.tsx           # registers ContinuousOpening
```

## Commands

```bash
cd /path/to/unzipped-project
npm ci
npm run typecheck
npm start -- --port=3100 --no-open
npm run still
npm run render
```

Select `ContinuousOpening` in Remotion Studio. Output: `out/continuous-opening.mp4`. 1280 × 720, 30 fps, 960 frames (32 seconds). No audio supplied. This downloadable project uses Remotion's managed Chrome browser for portable rendering on macOS. The cloud version separately uses its preinstalled Chromium. Remotion downloads its browser when first needed.

## Refinement

Edit points and cubic curves in `PolyUBuilding.tsx`. Its coordinates use the original reference photograph's 1400 × 650 proportions. Four path stages end at 4, 12, 22 and 30 seconds. Length milestones are calculated automatically; adding drawing detail does not require manually recomputing stroke lengths. All vertices remain connected; retraced edges let the pen reach another feature without lifting. The single line's corners are rounded. The top rim and cylinder seam use sampled Bezier curves.

The first sentence appears only from 0.6–4 seconds. No other text appears in the video. Background, brick red and stroke width are in `config.ts`. The complete source for this version is independent of the previous block/line-brick composition, which remains available unchanged.
