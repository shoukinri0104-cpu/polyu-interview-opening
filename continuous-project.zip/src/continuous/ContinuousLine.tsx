import React from 'react';
import {Easing,interpolate,useCurrentFrame,useVideoConfig} from 'remotion';
import {BUILDING,Point} from './PolyUBuilding';
import {LINE_CONFIG as C} from './config';
// Reveal the trajectory geometrically. This avoids slow SVG dash rasterization
// on retraced curved edges, while still drawing exactly one unbroken path.
export const revealedPath=(distance:number)=>{
 const visible:Point[]=[BUILDING.points[0]];
 let remaining=distance;
 for(let i=1;i<BUILDING.points.length;i++){
  const a=BUILDING.points[i-1],b=BUILDING.points[i];
  const length=Math.hypot(b[0]-a[0],b[1]-a[1]);
  if(remaining>=length){visible.push(b);remaining-=length;continue;}
  if(length>0)visible.push([a[0]+(b[0]-a[0])*remaining/length,a[1]+(b[1]-a[1])*remaining/length]);
  break;
 }
 return 'M '+visible.map(([x,y])=>[x+.55*Math.sin(y*.071+x*.019),y+.5*Math.sin(x*.043-y*.017)].map(n=>n.toFixed(2)).join(' ')).join(' L ');
};
export const ContinuousLine:React.FC=()=>{
 const frame=useCurrentFrame();const {fps}=useVideoConfig();
 const drawn=interpolate(frame/fps,C.stages,BUILDING.milestones,{easing:Easing.inOut(Easing.sin),extrapolateLeft:'clamp',extrapolateRight:'clamp'});
 return <svg viewBox="0 0 1400 650" width={C.drawing.width} height={C.drawing.height} style={{position:'absolute',left:C.drawing.left,top:C.drawing.top}}>
  <path d={drawn>=BUILDING.length?BUILDING.path:revealedPath(drawn)} fill="none" stroke={C.brickRed} strokeWidth={C.strokeWidth} strokeLinecap="round" strokeLinejoin="round" opacity={frame===0?0:1}/>
 </svg>;
};
