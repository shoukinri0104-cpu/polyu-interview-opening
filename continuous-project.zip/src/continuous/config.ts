export const LINE_CONFIG = {
  width:1280, height:720, fps:30, duration:32,
  background:'#FAF6EE',
  // Visually approximated from the reference facade; not an exact pixel sample.
  brickRed:'#985B58', strokeWidth:2.9,
  question:'What makes a structure last?',
  textFadeIn:0.6, textFadeOutStart:3.2, textEnd:4,
  // Stages map to measured cumulative path lengths, not arbitrary dash percentages.
  stages:[0,4,12,22,30],
  drawing:{left:100,top:150,width:1080,height:502},
};
