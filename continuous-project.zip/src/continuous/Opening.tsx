import React from 'react';
import {AbsoluteFill,interpolate,useCurrentFrame,useVideoConfig} from 'remotion';
import {LINE_CONFIG as C} from './config';
import {ContinuousLine} from './ContinuousLine';
export const ContinuousOpening:React.FC=()=>{
 const frame=useCurrentFrame();const {fps,width}=useVideoConfig();
 const opacity=interpolate(frame/fps,[C.textFadeIn,C.textFadeIn+.65,C.textFadeOutStart,C.textEnd],[0,1,1,0],{extrapolateLeft:'clamp',extrapolateRight:'clamp'});
 return <AbsoluteFill style={{background:C.background}}>
  <div style={{position:'absolute',width:1280,height:720,transform:`scale(${width/1280})`,transformOrigin:'top left'}}>
   <div style={{position:'absolute',top:170,left:0,width:'100%',textAlign:'center',fontFamily:'Arial, Helvetica, sans-serif',fontSize:29,fontWeight:400,letterSpacing:.1,color:C.brickRed,opacity}}>{C.question}</div>
   <ContinuousLine/>
  </div>
 </AbsoluteFill>;
};
